package com.taojin.pojo;

import lombok.Data;

@Data
public class TGoodsSearch {
    private Integer goodsTypeId;
    private String goodsName;
    private Integer price_min;
    private Integer price_max;
}