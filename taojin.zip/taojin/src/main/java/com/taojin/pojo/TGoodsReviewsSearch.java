package com.taojin.pojo;

import lombok.Data;

@Data
public class TGoodsReviewsSearch {
    private String userName;
    private String goodsName;
    private String time_min;
    private String time_max;
}
