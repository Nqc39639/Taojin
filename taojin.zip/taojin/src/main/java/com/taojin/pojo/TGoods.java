package com.taojin.pojo;

import lombok.Data;

import java.util.List;

@Data
public class TGoods {
    private Integer id;   // 商品ID
    private String goodsName;   // 商品名称
    private String goodsPicture;   // 商品图片
    private Integer goodsTypeId;   // 商品类型ID
    private String goodsTypeName;   // 商品类型名称
    private String goodsDetail;   // 商品详细描述
    private Integer goodsQuantity;   // 商品数量
    private Double goodsPrice;   // 商品价格
    private Integer goodsStatus;   // 商品状态（0: 求购, 1: 在售）
    private String goodsStatusName;   // 商品状态名称
    private int[] goodsReviewId;   // 商品评价ID
    private List<TGoodsReviews> tGoodsReviews;   // 商品评价信息
    private Integer userId;   // 用户ID
    private TUsers tUsers;   // 用户信息

    public void setGoodsTypeId(Integer goodsTypeId) {
        this.goodsTypeId = goodsTypeId;
        if (goodsTypeId == 1) {
            this.goodsTypeName = "男装";
        } else if (goodsTypeId == 2) {
            this.goodsTypeName = "女装";
        } else if (goodsTypeId == 3) {
            this.goodsTypeName = "鞋袜";
        } else if (goodsTypeId == 4) {
            this.goodsTypeName = "饰品";
        } else if (goodsTypeId == 5) {
            this.goodsTypeName = "数码电子";
        } else if (goodsTypeId == 6) {
            this.goodsTypeName = "电器家具";
        } else if (goodsTypeId == 7) {
            this.goodsTypeName = "百货";
        } else if (goodsTypeId == 8) {
            this.goodsTypeName = "图书";
        } else if (goodsTypeId == 9) {
            this.goodsTypeName = "医药";
        } else if (goodsTypeId == 10) {
            this.goodsTypeName = "宠物花卉";
        } else if (goodsTypeId == 11) {
            this.goodsTypeName = "生活载具";
        } else {
            this.goodsTypeName = "二手房";
        }
    }

    public void setGoodsStatus(Integer goodsStatus) {
        this.goodsStatus = goodsStatus;
        if (goodsStatus == 1) {
            this.goodsStatusName = "在售";
        } else if (goodsStatus == 0) {
            this.goodsStatusName = "求购";
        }
    }
}
