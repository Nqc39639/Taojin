package com.taojin.pojo;

import lombok.Data;

@Data
public class TGoodsSearchParams {
    private String condition;
}
