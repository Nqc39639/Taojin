package com.taojin.pojo;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.Date;

public class TUsers {
    private Integer id;   // 用户ID
    private String userName;   // 用户昵称
    private String account;   // 账号
    private String password;   // 密码
    private Integer gender;   // 性别（0: 女, 1: 男, 2: 保密）
    private String genders;   // 性别
    private Integer age;   // 年龄
    @JSONField(format = "yyyy-MM-dd")
    private Date birthday;   // 生日
    private String telephone;   // 联系电话
    private String address;   // 收货地址
    private String email;   // 邮箱
    private String avatar;   // 头像
    private Integer userType;   // 用户类型（0: 实名用户, 1: 管理员）
    private String userTypes;   // 用户类型
    private Double balance;   // 余额
    private Integer status;   // 状态（0: 离线, 1: 在线）

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
        if (gender == 1) {
            this.genders = "男";
        } else if (gender == 0) {
            this.genders = "女";
        } else {
            this.genders = "保密";
        }
    }

    public String getGenders() {
        return genders;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
        if (userType == 1) {
            this.userTypes = "管理员";
        } else {
            this.userTypes = "真实用户";
        }
    }

    public String getUserTypes() {
        return userTypes;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TUsers{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", account='" + account + '\'' +
                ", password='" + password + '\'' +
                ", gender=" + gender +
                ", genders='" + genders + '\'' +
                ", age=" + age +
                ", birthday=" + birthday +
                ", telephone='" + telephone + '\'' +
                ", address='" + address + '\'' +
                ", email='" + email + '\'' +
                ", avatar='" + avatar + '\'' +
                ", userType=" + userType +
                ", userTypes='" + userTypes + '\'' +
                ", balance=" + balance +
                ", status=" + status +
                '}';
    }
}
