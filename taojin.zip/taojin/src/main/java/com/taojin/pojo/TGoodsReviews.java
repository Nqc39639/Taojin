package com.taojin.pojo;

import com.alibaba.fastjson.annotation.JSONField;
import com.taojin.service.TGoodsService;
import com.taojin.service.TUsersService;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class TGoodsReviews {
    TUsersService tUsersService = new TUsersService();
    TGoodsService tGoodsService = new TGoodsService();

    private Integer id;   // 商品评价ID
    private Integer userId;   // 用户ID
    private List<TUsers> tUsers;   // 该评价对应的用户信息
    private String userName;   // 用户昵称
    private String account;   // 账号
    private String password;   // 密码
    private Integer gender;   // 性别（0: 女, 1: 男, 2: 保密）
    private String genders;   // 性别
    private Integer age;   // 年龄
    @JSONField(format = "yyyy-MM-dd")
    private Date birthday;   // 生日
    private String telephone;   // 联系电话
    private String address;   // 收货地址
    private String email;   // 邮箱
    private String avatar;   // 头像
    private Integer userType;   // 用户类型（0: 实名用户, 1: 管理员）
    private String userTypes;   // 用户类型
    private Double balance;   // 余额
    private Integer status;   // 状态（0: 离线, 1: 在线）
    private Integer goodsId;   // 商品ID
    private List<TGoods> tGoods;
    private String goodsName;   // 商品名称
    private String goodsPicture;   // 商品图片
    private Integer goodsTypeId;   // 商品类型ID
    private String goodsTypeName;   // 商品类型名称
    private String goodsDetail;   // 商品详细描述
    private Integer goodsQuantity;   // 商品数量
    private Double goodsPrice;   // 商品价格
    private Integer goodsStatus;   // 商品状态（0: 求购, 1: 在售）
    private String goodsStatusName;   // 商品状态名称
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date goodsReviewTime;   // 评价时间
    private String goodsReviewDetail;   // 商品评价内容

    public void setUserId(Integer userId) {
        this.userId = userId;
        this.tUsers = tUsersService.GetTUserById(userId);
        this.userName = this.tUsers.get(0).getUserName();
        this.account = this.tUsers.get(0).getAccount();
        this.password = this.tUsers.get(0).getPassword();
        setGender(this.tUsers.get(0).getGender());
        this.age = this.tUsers.get(0).getAge();
        this.birthday = this.tUsers.get(0).getBirthday();
        this.telephone = this.tUsers.get(0).getTelephone();
        this.address = this.tUsers.get(0).getAddress();
        this.email = this.tUsers.get(0).getEmail();
        this.avatar = this.tUsers.get(0).getAvatar();
        setUserType(this.tUsers.get(0).getUserType());
        this.balance = this.tUsers.get(0).getBalance();
        this.status = this.tUsers.get(0).getStatus();
    }

    public void setGender(Integer gender) {
        this.gender = gender;
        if (gender == 1) {
            this.genders = "男";
        } else if (gender == 0) {
            this.genders = "女";
        } else {
            this.genders = "保密";
        }
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
        if (userType == 1) {
            this.userTypes = "管理员";
        } else {
            this.userTypes = "真实用户";
        }
    }

    public void setGoodsId(Integer goodsId) {
        this.goodsId = goodsId;
        this.tGoods = tGoodsService.GetTGoodsById(goodsId);
        this.goodsName = this.tGoods.get(0).getGoodsName();
        this.goodsPicture = this.tGoods.get(0).getGoodsPicture();
        setGoodsTypeId(this.tGoods.get(0).getGoodsTypeId());
        this.goodsDetail = this.tGoods.get(0).getGoodsDetail();
        this.goodsQuantity = this.tGoods.get(0).getGoodsQuantity();
        this.goodsPrice = this.tGoods.get(0).getGoodsPrice();
        setGoodsStatus(this.tGoods.get(0).getGoodsStatus());
    }

    public void setGoodsTypeId(Integer goodsTypeId) {
        this.goodsTypeId = goodsTypeId;
        if (goodsTypeId == 1) {
            this.goodsTypeName = "男装";
        } else if (goodsTypeId == 2) {
            this.goodsTypeName = "女装";
        } else if (goodsTypeId == 3) {
            this.goodsTypeName = "鞋袜";
        } else if (goodsTypeId == 4) {
            this.goodsTypeName = "饰品";
        } else if (goodsTypeId == 5) {
            this.goodsTypeName = "数码电子";
        } else if (goodsTypeId == 6) {
            this.goodsTypeName = "电器家具";
        } else if (goodsTypeId == 7) {
            this.goodsTypeName = "百货";
        } else if (goodsTypeId == 8) {
            this.goodsTypeName = "图书";
        } else if (goodsTypeId == 9) {
            this.goodsTypeName = "医药";
        } else if (goodsTypeId == 10) {
            this.goodsTypeName = "宠物花卉";
        } else if (goodsTypeId == 11) {
            this.goodsTypeName = "生活载具";
        } else {
            this.goodsTypeName = "二手房";
        }
    }

    public void setGoodsStatus(Integer goodsStatus) {
        this.goodsStatus = goodsStatus;
        if (goodsStatus == 1) {
            this.goodsStatusName = "在售";
        } else if (goodsStatus == 0) {
            this.goodsStatusName = "求购";
        }
    }
}
