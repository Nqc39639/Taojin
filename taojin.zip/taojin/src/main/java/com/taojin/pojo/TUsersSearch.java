package com.taojin.pojo;

import lombok.Data;

@Data
public class TUsersSearch {
    private Integer gender;
    private String address;
    private Integer age_min;
    private Integer age_max;
}
