package com.taojin.pojo;

import lombok.Data;

@Data
public class TGoodsTypes {
    private Integer id;   // 商品类型ID
    private String goodsTypesName;   // 商品类型名称
    private String tGoodsNames;
}
