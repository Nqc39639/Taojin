package com.taojin.service;

import com.taojin.mapper.TGoodsReviewsMapper;
import com.taojin.pojo.TGoodsReviews;
import com.taojin.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class TGoodsReviewsService {
    static SqlSession sqlSession = SqlSessionFactoryUtil.getSqlSession();

    // 根据商品ID查询商品评论
    public List<TGoodsReviews> GetTReviewsByGoodsId(Integer goodsId) {
        TGoodsReviewsMapper tGoodsReviewsMapper = sqlSession.getMapper(TGoodsReviewsMapper.class);
        return tGoodsReviewsMapper.selectByTGoodsId(goodsId);
    }

    //根据参数查询商品评论
    public List<TGoodsReviews> GetTGoodsReviews(Integer userId, Integer goodsId, String time_min, String time_max) {
        TGoodsReviewsMapper tGoodsReviewsMapper = sqlSession.getMapper(TGoodsReviewsMapper.class);
        List<TGoodsReviews> listReviews = null;
        if ((userId != null) || (goodsId != null) || (!time_min.isEmpty()) || (!time_max.isEmpty())) {
            listReviews = tGoodsReviewsMapper.selectBySearchReviews(userId, goodsId, time_min, time_max);
        } else {
            listReviews = tGoodsReviewsMapper.selectAll();
        }
        return listReviews;
    }

    // 添加评论
    public Integer AddTGoodsReviews(TGoodsReviews tGoodsReviews) {
        TGoodsReviewsMapper tGoodsReviewsMapper = sqlSession.getMapper(TGoodsReviewsMapper.class);
        Integer flag;
        try {
            flag = tGoodsReviewsMapper.add(tGoodsReviews);
            sqlSession.commit();
        } catch (Exception e) {
            e.printStackTrace();
            flag = 0;
        }
        return flag;
    }
}
