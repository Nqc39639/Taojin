package com.taojin.service;

import com.alibaba.fastjson.JSON;
import com.taojin.mapper.TGoodsMapper;
import com.taojin.pojo.TGoods;
import com.taojin.pojo.TGoodsSearch;
import com.taojin.pojo.TGoodsSearchParams;
import com.taojin.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.Comparator;
import java.util.List;

public class TGoodsService {
    static SqlSession sqlSession = SqlSessionFactoryUtil.getSqlSession();

    // 根据条件查找所有在售商品信息
    public List<TGoods> GetTGoodsOnSale(String searchParams) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        List<TGoods> listOnSale = null;
        if (searchParams.isEmpty()) {
            listOnSale = tGoodsMapper.selectByTGoodsStatus(1);
        } else {
            TGoodsSearch search = JSON.parseObject(searchParams, TGoodsSearch.class);
            listOnSale = tGoodsMapper.selectBySearchOnSaleStr(search);
        }
        listOnSale.sort(new Comparator<TGoods>() {
            @Override
            public int compare(TGoods o1, TGoods o2) {
                if (o1.getId().compareTo(o2.getId()) > 0) {
                    return -1;
                } else if (o1.getId().compareTo(o2.getId()) < 0) {
                    return 1;
                }
                return 0;
            }
        });
        return listOnSale;
    }

    // 根据条件查找所有求购商品信息
    public List<TGoods> GetTGoodsForBuying(String searchParams) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        List<TGoods> listOnSale = null;
        if (searchParams.isEmpty()) {
            listOnSale = tGoodsMapper.selectByTGoodsStatus(0);
        } else {
            TGoodsSearch searchPara = JSON.parseObject(searchParams, TGoodsSearch.class);
            listOnSale = tGoodsMapper.selectBySearchForBuyingStr(searchPara);
        }
        listOnSale.sort(new Comparator<TGoods>() {
            @Override
            public int compare(TGoods o1, TGoods o2) {
                if (o1.getGoodsPrice().compareTo(o2.getGoodsPrice()) > 0) {
                    return -1;
                } else if (o1.getGoodsPrice().compareTo(o2.getGoodsPrice()) < 0) {
                    return 1;
                }
                return 0;
            }
        });
        return listOnSale;
    }

    //根据商品名称和商品详细说明在前台进行条件查询
    public List<TGoods> GetTGoodsForSearch(String searchParams) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        List<TGoods> listOnSale = null;
        if (searchParams.isEmpty()) {
            listOnSale = tGoodsMapper.selectByTGoodsStatus(1);
        } else {
            TGoodsSearchParams searchPara = JSON.parseObject(searchParams, TGoodsSearchParams.class);
            listOnSale = tGoodsMapper.selectByConditions(searchPara);
        }
        return listOnSale;
    }

    // 根据商品ID查找
    public List<TGoods> GetTGoodsById(Integer id) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        return tGoodsMapper.selectById(id);
    }

    // 根据商品名称查找
    public TGoods GetTGoodsByName(String goodsName) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        return tGoodsMapper.selectByTGoodsName(goodsName);
    }

    // 根据商品类型查找
    public List<TGoods> GetTGoodsByTypeId(Integer goodsTypeId) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        return tGoodsMapper.selectByTGoodsTypeId(goodsTypeId);
    }

    // 根据商品状态查找
    public List<TGoods> GetTGoodsByStatus(Integer goodsStatus) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        return tGoodsMapper.selectByTGoodsStatus(goodsStatus);
    }

    // 根据商品价格查找
    public List<TGoods> GetTGoodsByPrice(Double min, Double max) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        return tGoodsMapper.selectByTGoodsPriceIn(min, max);
    }

    public List<TGoods> GetTGoodsByPrice(Double min) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        return tGoodsMapper.selectByTGoodsPriceMoreThan(min);
    }

    // 添加商品求购/出售信息
    public Integer AddTGoods(TGoods tGoods) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        Integer flag;
        try {
            flag = tGoodsMapper.add(tGoods);
            sqlSession.commit();
        } catch (Exception e) {
            flag = 0;
        }
        return flag;
    }

    // 删除商品信息
    public Integer DeleteTGoods(int[] ids) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        Integer flag;
        try {
            flag = tGoodsMapper.delete(ids);
            sqlSession.commit();
        } catch (Exception e) {
            flag = 0;
        }
        return flag;
    }

    // 修改商品信息(包括购买商品)
    public Integer UpdateTGoods(TGoods tGoods) {
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        Integer flag;
        try {
            flag = tGoodsMapper.update(tGoods);
            sqlSession.commit();
        } catch (Exception e) {
            flag = 0;
        }
        return flag;
    }
}
