package com.taojin.service;

import com.alibaba.fastjson.JSON;
import com.taojin.mapper.TUsersMapper;
import com.taojin.pojo.TUsers;
import com.taojin.pojo.TUsersSearch;
import com.taojin.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.Comparator;
import java.util.List;

public class TUsersService {
    static SqlSession sqlSession = SqlSessionFactoryUtil.getSqlSession();

    // 登陆验证
    public List<TUsers> CheckTUser(String account, String password) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        return tUsersMapper.check(account, password);
    }

    // 查询所有用户的信息
    public List<TUsers> GetAllTUsers(String searchParams) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        List<TUsers> allList = null;
        if (searchParams.isEmpty()) {
            allList = tUsersMapper.selectAll();
        } else {
            TUsersSearch search = JSON.parseObject(searchParams, TUsersSearch.class);
            allList = tUsersMapper.selectBySearchAll(search);
        }
        allList.sort(new Comparator<TUsers>() {
            @Override
            public int compare(TUsers o1, TUsers o2) {
                if (o1.getId().compareTo(o2.getId()) > 0) {
                    return -1;
                } else if (o1.getId().compareTo(o2.getId()) < 0) {
                    return 1;
                }
                return 0;
            }
        });
        return allList;
    }

    // 查询在线用户的信息
    public List<TUsers> GetOnlineTUsers(String searchParams) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        List<TUsers> allList = null;
        if (searchParams.isEmpty()) {
            allList = tUsersMapper.selectOnline();
        } else {
            TUsersSearch search = JSON.parseObject(searchParams, TUsersSearch.class);
            allList = tUsersMapper.selectBySearchOnline(search);
        }
        allList.sort(new Comparator<TUsers>() {
            @Override
            public int compare(TUsers o1, TUsers o2) {
                if (o1.getId().compareTo(o2.getId()) > 0) {
                    return -1;
                } else if (o1.getId().compareTo(o2.getId()) < 0) {
                    return 1;
                }
                return 0;
            }
        });
        return allList;
    }

    // 通过id查询用户信息
    public List<TUsers> GetTUserById(Integer id) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        return tUsersMapper.selectById(id);
    }

    // 通过用户名查询用户信息
    public TUsers GetTUserByUserName(String userName) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        return tUsersMapper.selectByUserName(userName);
    }

    // 通过账号查询用户信息
    public List<TUsers> GetTUserByAccount(String account) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        return tUsersMapper.selectByAccount(account);
    }

    // 添加账户信息
    public Integer AddTUser(TUsers tUsers) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        Integer flag;
        try {
            flag = tUsersMapper.add(tUsers);
            sqlSession.commit();
        } catch (Exception e) {
            flag = 0;
        }
        return flag;
    }

    // 删除账户信息
    public void DeleteTUsers(int[] ids) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        tUsersMapper.delete(ids);
        sqlSession.commit();
    }

    // 修改用户信息
    public void UpdateTUser(TUsers tUsers) {
        TUsersMapper tUsersMapper = sqlSession.getMapper(TUsersMapper.class);
        tUsersMapper.update(tUsers);
        sqlSession.commit();
    }
}
