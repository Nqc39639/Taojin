package com.taojin.service;

import com.taojin.mapper.TGoodsMapper;
import com.taojin.mapper.TGoodsTypesMapper;
import com.taojin.pojo.TGoods;
import com.taojin.pojo.TGoodsTypes;
import com.taojin.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class TGoodsTypesService {
    static SqlSession sqlSession = SqlSessionFactoryUtil.getSqlSession();

    public List<TGoodsTypes> GetAllTGoodsType() {
        TGoodsTypesMapper tGoodsTypesMapper = sqlSession.getMapper(TGoodsTypesMapper.class);
        TGoodsMapper tGoodsMapper = sqlSession.getMapper(TGoodsMapper.class);
        List<TGoodsTypes> allList = tGoodsTypesMapper.selectAll();
        for (TGoodsTypes rt : allList) {
            int[] ids = tGoodsTypesMapper.selectTGoodsIdByTypeId(rt.getId());
            if (ids != null && ids.length > 0) {
                List<TGoods> tGoods = tGoodsMapper.selectByIds(ids);
                StringBuilder ss = new StringBuilder();
                for (TGoods tGood : tGoods) {
                    ss.append(tGood.getGoodsName()).append("; ");
                }
                rt.setTGoodsNames(ss.toString());
            }
        }

        return allList;
    }

    public void DeleteTGoods(int[] ids) {
        TGoodsMapper mapper = sqlSession.getMapper(TGoodsMapper.class);
        mapper.delete(ids);
    }
}
