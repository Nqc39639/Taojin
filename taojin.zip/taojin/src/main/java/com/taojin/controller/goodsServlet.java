package com.taojin.controller;

import com.alibaba.fastjson.JSON;
import com.taojin.pojo.TGoods;
import com.taojin.pojo.TGoodsReviews;
import com.taojin.pojo.TGoodsReviewsSearch;
import com.taojin.pojo.TUsers;
import com.taojin.service.TGoodsReviewsService;
import com.taojin.service.TGoodsService;
import com.taojin.service.TUsersService;
import com.taojin.util.R;
import lombok.SneakyThrows;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet("/goods")
public class goodsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String operation = request.getParameter("operation") == null ? "" : request.getParameter("operation");
        String goodsType = request.getParameter("goodsType") == null ? "" : request.getParameter("goodsType");
        String goodsId = request.getParameter("goodsId") == null ? "" : request.getParameter("goodsId");
        TGoodsService tGoodsService = new TGoodsService();
        TGoodsReviewsService tGoodsReviewsService = new TGoodsReviewsService();
        List<TGoods> list = null;
        if (operation.equals("classes")) {
            if (!goodsType.isEmpty()) list = tGoodsService.GetTGoodsByTypeId(Integer.valueOf(goodsType));
            R success = R.success(list.size(), list);
            String goodsList = JSON.toJSONString(success);
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(goodsList.getBytes(StandardCharsets.UTF_8));
        } else if (operation.equals("detail")) {
            List<TGoodsReviews> reviewsList = null;
            if (!goodsId.isEmpty()) {
                list = tGoodsService.GetTGoodsById(Integer.valueOf(goodsId));
                reviewsList = tGoodsReviewsService.GetTReviewsByGoodsId(Integer.valueOf(goodsId));
            }
            list.get(0).setTGoodsReviews(reviewsList);
            R success = R.success(list.size(), list);
            String goodsList = JSON.toJSONString(success);
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(goodsList.getBytes(StandardCharsets.UTF_8));
        } else {
            list = tGoodsService.GetTGoodsByStatus(1);
            R success = R.success(list.size(), list);
            String goodsList = JSON.toJSONString(success);
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(goodsList.getBytes(StandardCharsets.UTF_8));
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String operation = request.getParameter("operation") == null ? "" : request.getParameter("operation");
        String searchParams = request.getParameter("searchParams") == null ? "" : request.getParameter("searchParams");
        TGoodsService tGoodsService = new TGoodsService();
        TGoodsReviewsService tGoodsReviewsService = new TGoodsReviewsService();
        Integer flag = null;
        switch (operation) {
            case "search":
                List<TGoods> list2 = tGoodsService.GetTGoodsForSearch(searchParams);
                R success2 = R.success(list2.size(), list2);
                String goodsListForSearch = JSON.toJSONString(success2);
                ServletOutputStream outputStreamForSearch = response.getOutputStream();
                outputStreamForSearch.write(goodsListForSearch.getBytes(StandardCharsets.UTF_8));
                break;
            case "queryComment":
                TUsersService tUsersService = new TUsersService();
                TGoodsReviewsSearch search = JSON.parseObject(searchParams, TGoodsReviewsSearch.class);
                if (search != null) {
                    Integer userId = search.getUserName().isEmpty() ? null : tUsersService.GetTUserByUserName(search.getUserName()).getId();
                    Integer goodsId = search.getGoodsName().isEmpty() ? null : tGoodsService.GetTGoodsByName(search.getGoodsName()).getId();
                    String time_min = search.getTime_min();
                    String time_max = search.getTime_max();
                    List<TGoodsReviews> tGoodsReviews = tGoodsReviewsService.GetTGoodsReviews(userId, goodsId, time_min, time_max);
                    R successReview = R.success(tGoodsReviews.size(), tGoodsReviews);
                    String goodsListReview = JSON.toJSONString(successReview);
                    ServletOutputStream outputStreamReview = response.getOutputStream();
                    outputStreamReview.write(goodsListReview.getBytes(StandardCharsets.UTF_8));
                } else {
                    Integer userId = null;
                    Integer goodsId = null;
                    String time_min = "";
                    String time_max = "";
                    List<TGoodsReviews> tGoodsReviews = tGoodsReviewsService.GetTGoodsReviews(userId, goodsId, time_min, time_max);
                    R successReview = R.success(tGoodsReviews.size(), tGoodsReviews);
                    String goodsListReview = JSON.toJSONString(successReview);
                    ServletOutputStream outputStreamReview = response.getOutputStream();
                    outputStreamReview.write(goodsListReview.getBytes(StandardCharsets.UTF_8));
                }
                break;
            case "sell":
                TGoods sellTGoods = getTGoods(request);
                sellTGoods.setGoodsStatus(1);
                flag = tGoodsService.AddTGoods(sellTGoods);
                response.setContentType("application/json;charset=utf-8");
                if (flag > 0) {
                    response.getWriter().print(JSON.toJSONString(R.success()));
                } else {
                    response.getWriter().print(JSON.toJSONString(R.fail()));
                }
                break;
            case "request":
                TGoods requestTGoods = getTGoods(request);
                requestTGoods.setGoodsStatus(0);
                flag = tGoodsService.AddTGoods(requestTGoods);
                response.setContentType("application/json;charset=utf-8");
                if (flag > 0) {
                    response.getWriter().print(JSON.toJSONString(R.success()));
                } else {
                    response.getWriter().print(JSON.toJSONString(R.fail()));
                }
                break;
            case "delete":
                String idString = request.getParameter("ids");
                List<String> idList = Arrays.asList(idString.split(","));
                int[] ids = new int[idList.size()];
                for (int i = 0; i < idList.size(); i++) {
                    ids[i] = Integer.parseInt(idList.get(i));
                }
                flag = tGoodsService.DeleteTGoods(ids);
                response.setContentType("application/json;charset=utf-8");
                if (flag > 0) {
                    response.getWriter().print(JSON.toJSONString(R.success()));
                } else {
                    response.getWriter().print(JSON.toJSONString(R.fail()));
                }
                break;
            case "updateOnSale":
                TGoods updateTGoods = getTGoods(request);
                updateTGoods.setGoodsStatus(1);
                flag = tGoodsService.UpdateTGoods(updateTGoods);
                response.setContentType("application/json;charset=utf-8");
                if (flag > 0) {
                    response.getWriter().print(JSON.toJSONString(R.success()));
                } else {
                    response.getWriter().print(JSON.toJSONString(R.fail()));
                }
                break;
            case "updateForBuying":
                TGoods updateTGoodsForBuying = getTGoods(request);
                updateTGoodsForBuying.setGoodsStatus(0);
                flag = tGoodsService.UpdateTGoods(updateTGoodsForBuying);
                response.setContentType("application/json;charset=utf-8");
                if (flag > 0) {
                    response.getWriter().print(JSON.toJSONString(R.success()));
                } else {
                    response.getWriter().print(JSON.toJSONString(R.fail()));
                }
                break;
            case "queryOnSale":
                response.setContentType("application/json;charset=utf-8");
                List<TGoods> list = tGoodsService.GetTGoodsOnSale(searchParams);
                R success = R.success(list.size(), list);
                String goodsListOnSale = JSON.toJSONString(success);
                ServletOutputStream outputStream = response.getOutputStream();
                outputStream.write(goodsListOnSale.getBytes(StandardCharsets.UTF_8));
                break;
            case "queryForBuying":
                response.setContentType("application/json;charset=utf-8");
                List<TGoods> list1 = tGoodsService.GetTGoodsForBuying(searchParams);
                R success1 = R.success(list1.size(), list1);
                String goodsListForBuying = JSON.toJSONString(success1);
                ServletOutputStream outputStreamForBuying = response.getOutputStream();
                outputStreamForBuying.write(goodsListForBuying.getBytes(StandardCharsets.UTF_8));
                break;
            case "comment":
                TGoodsReviews tGoodsReviews = getTGoodsReviews(request);
                flag = tGoodsReviewsService.AddTGoodsReviews(tGoodsReviews);
                response.setContentType("application/json;charset=utf-8");
                if (flag > 0) {
                    response.getWriter().print(JSON.toJSONString(R.success()));
                } else {
                    response.getWriter().print(JSON.toJSONString(R.fail()));
                }
                break;
            case "uploadOnSale":
            case "uploadForBuying":
            case "upload":
                uploadFile(request, response);
                break;
            default:
                break;
        }
    }

    public TGoods getTGoods(HttpServletRequest request) {
        String id = request.getParameter("id") == null ? "" : request.getParameter("id");
        String goodsName = request.getParameter("goodsName");
        String goodsPicture = request.getParameter("goodsPicture");
        String goodsTypeId = request.getParameter("goodsTypeId");
        String goodsDetail = request.getParameter("goodsDetail");
        String goodsQuantity = request.getParameter("goodsQuantity");
        String goodsPrice = request.getParameter("goodsPrice");
        TUsers tUser = (TUsers) request.getSession().getAttribute("tUser");
        TGoods tGoods = new TGoods();
        if (!id.isEmpty()) tGoods.setId(Integer.valueOf(id));
        if (goodsName != null && !goodsName.isEmpty()) tGoods.setGoodsName(goodsName);
        if (goodsPicture != null && !goodsPicture.isEmpty()) tGoods.setGoodsPicture(goodsPicture);
        if (goodsTypeId != null && !goodsTypeId.equals("0")) tGoods.setGoodsTypeId(Integer.valueOf(goodsTypeId));
        if (goodsDetail != null && !goodsDetail.isEmpty()) tGoods.setGoodsDetail(goodsDetail);
        if (goodsQuantity != null && !goodsQuantity.isEmpty()) tGoods.setGoodsQuantity(Integer.valueOf(goodsQuantity));
        if (goodsPrice != null && !goodsPrice.isEmpty()) tGoods.setGoodsPrice(Double.valueOf(goodsPrice));
        tGoods.setUserId(tUser.getId());
        return tGoods;
    }

    @SneakyThrows
    public TGoodsReviews getTGoodsReviews(HttpServletRequest request) {
        String userId = request.getParameter("userId");
        String goodsId = request.getParameter("goodsId");
        String goodsReviewTime = request.getParameter("goodsReviewTime");
        String goodsReviewDetail = request.getParameter("goodsReviewDetail");
        TGoodsReviews tGoodsReviews = new TGoodsReviews();
        if (userId != null && !userId.isEmpty()) tGoodsReviews.setUserId(Integer.valueOf(userId));
        if (goodsId != null && !goodsId.isEmpty()) tGoodsReviews.setGoodsId(Integer.valueOf(goodsId));
        if (goodsReviewTime != null && !goodsReviewTime.isEmpty()) {
            String replace = goodsReviewTime.replace('/', '-');
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                Date parse = simpleDateFormat.parse(replace);
                tGoodsReviews.setGoodsReviewTime(parse);
            } catch (Exception e) {
                e.printStackTrace();
                tGoodsReviews.setGoodsReviewTime(new Date());
            }
        }
        if (goodsReviewDetail != null && !goodsReviewDetail.isEmpty())
            tGoodsReviews.setGoodsReviewDetail(goodsReviewDetail);
        return tGoodsReviews;
    }

    @SneakyThrows
    private void uploadFile(HttpServletRequest request, HttpServletResponse response) {
        //真实上传到的文件地址
        String filePath = "D:\\taojin\\goodsPicture";
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        //解析请求信息
        List<FileItem> fileItems = upload.parseRequest(request);
        String fileName = "";
        Iterator<FileItem> iterator = fileItems.iterator();
        if (iterator.hasNext()) {
            FileItem item = iterator.next();
            fileName = item.getName();
            //获取文件的后缀名
            String suffName = fileName.substring(fileName.lastIndexOf("."));
            //随机生成文件名称
            fileName = UUID.randomUUID() + suffName;
            request.setAttribute("fileName", fileName);
            File f = new File(filePath);
            if (!f.exists()) {
                f.mkdirs();
            }
            File file = new File(filePath, fileName);
            item.write(file);
        }
        response.setContentType("application/json;charset=utf-8");
        String json = JSON.toJSONString(R.success(fileName, null));
        response.getWriter().print(json);
    }

}
