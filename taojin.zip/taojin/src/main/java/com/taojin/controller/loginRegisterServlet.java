package com.taojin.controller;

import com.taojin.pojo.TUsers;
import com.taojin.service.TUsersService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/loginRegister")
public class loginRegisterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String operation = request.getParameter("operation");
        HttpSession session = request.getSession();
        switch (operation) {
            case "logout":
                TUsersService tUsersService = new TUsersService();
                TUsers tUsers = (TUsers) session.getAttribute("tUser");
                tUsers.setStatus(0);
                tUsersService.UpdateTUser(tUsers);
                Map<TUsers, Boolean> map = (Map<TUsers, Boolean>) request.getServletContext().getAttribute("online");
                System.out.println("old::" + map);
                if (map.containsKey(tUsers)) {   // 指定用户信息存在
                    map.put(tUsers, false);   // 修改为注销状态
                    request.getServletContext().setAttribute("online", map);   // 属性更新
                    System.out.println("new::" + request.getServletContext().getAttribute("online"));
                }
                session.removeAttribute("tUser");
                response.sendRedirect("home.jsp");
                break;
            case "login":
            default:
                response.sendRedirect("loginRegister.jsp");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String operation = request.getParameter("operation");
        String account = request.getParameter("account");
        TUsersService tUsersService = new TUsersService();
        switch (operation) {
            case "login":
                String LPassword = request.getParameter("LPassword");
                List<TUsers> list1 = tUsersService.GetTUserByAccount(account);
                List<TUsers> list2 = tUsersService.CheckTUser(account, LPassword);
                if (list1 == null || list1.size() == 0) {
                    request.setAttribute("loginMsg", "账号不存在！");
                    request.getRequestDispatcher("loginRegister.jsp").forward(request, response);
                } else if (list2 == null || list2.size() == 0) {
                    request.setAttribute("loginMsg", "密码错误！");
                    request.getRequestDispatcher("loginRegister.jsp").forward(request, response);
                } else {
                    list2.get(0).setStatus(1);
                    tUsersService.UpdateTUser(list2.get(0));
                    System.out.println("成功！");
                    HttpSession session = request.getSession();
                    session.setAttribute("tUser", list2.get(0));
                    response.sendRedirect("home.jsp");
                }
                break;
            case "register":
                String userName = request.getParameter("userName");
                String RPassword = request.getParameter("RPassword");
                List<TUsers> list3 = tUsersService.GetTUserByAccount(account);
                if (list3 != null && list3.size() != 0) {
                    request.setAttribute("registerMsg", "账号已存在！");
                    request.getRequestDispatcher("loginRegister.jsp").forward(request, response);
                } else {
                    TUsers tUsers = new TUsers();
                    tUsers.setUserName(userName);
                    tUsers.setAccount(account);
                    tUsers.setPassword(RPassword);
                    tUsers.setGender(2);
                    tUsers.setUserType(0);
                    Integer flag = tUsersService.AddTUser(tUsers);
                    // response.setContentType("application/json;charset=utf-8");
                    if (flag > 0) {
                        request.setAttribute("registerMsg", "注册成功！");
                        request.getRequestDispatcher("loginRegister.jsp").forward(request, response);
                    } else {
                        request.setAttribute("registerMsg", "注册失败！");
                        request.getRequestDispatcher("loginRegister.jsp").forward(request, response);
                    }
                }
                break;
        }
    }
}
