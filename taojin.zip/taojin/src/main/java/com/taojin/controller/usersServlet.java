package com.taojin.controller;

import com.alibaba.fastjson.JSON;
import com.taojin.pojo.TUsers;
import com.taojin.service.TUsersService;
import com.taojin.util.R;
import lombok.SneakyThrows;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet("/users")
public class usersServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String operation = request.getParameter("operation") == null ? "" : request.getParameter("operation");
        String searchParams = request.getParameter("searchParams") == null ? "" : request.getParameter("searchParams");
        TUsersService tUsersService = new TUsersService();
        switch (operation) {
            case "queryAll":
                response.setContentType("application/json;charset=utf-8");
                List<TUsers> list = tUsersService.GetAllTUsers(searchParams);
                R success = R.success(list.size(), list);
                String usersList = JSON.toJSONString(success);
                ServletOutputStream outputStream = response.getOutputStream();
                outputStream.write(usersList.getBytes(StandardCharsets.UTF_8));
                break;
            case "queryOnline":
                response.setContentType("application/json;charset=utf-8");
                List<TUsers> onlineList = tUsersService.GetOnlineTUsers(searchParams);
                R onlineSuccess = R.success(onlineList.size(), onlineList);
                String usersOnlineList = JSON.toJSONString(onlineSuccess);
                ServletOutputStream outputStreamOnline = response.getOutputStream();
                outputStreamOnline.write(usersOnlineList.getBytes(StandardCharsets.UTF_8));
                break;
            default:
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String operation = request.getParameter("operation") == null ? "" : request.getParameter("operation");
        String searchParams = request.getParameter("searchParams") == null ? "" : request.getParameter("searchParams");
        TUsersService tUsersService = new TUsersService();
        switch (operation) {
            case "queryAll":
                response.setContentType("application/json;charset=utf-8");
                List<TUsers> list = tUsersService.GetAllTUsers(searchParams);
                R success = R.success(list.size(), list);
                String usersList = JSON.toJSONString(success);
                ServletOutputStream outputStream = response.getOutputStream();
                outputStream.write(usersList.getBytes(StandardCharsets.UTF_8));
                break;
            case "queryOnline":
                response.setContentType("application/json;charset=utf-8");
                List<TUsers> onlineList = tUsersService.GetOnlineTUsers(searchParams);
                R onlineSuccess = R.success(onlineList.size(), onlineList);
                String usersOnlineList = JSON.toJSONString(onlineSuccess);
                ServletOutputStream outputStreamOnline = response.getOutputStream();
                outputStreamOnline.write(usersOnlineList.getBytes(StandardCharsets.UTF_8));
                break;
            case "add":
                TUsers addTUsers = getTUsers(request);
                tUsersService.AddTUser(addTUsers);
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().print(JSON.toJSONString(R.success()));
                break;
            case "delete":
                String idString = request.getParameter("idString");
                List<String> idList = Arrays.asList(idString.split(","));
                int[] ids = new int[idList.size()];
                for (int i = 0; i < idList.size(); i++) {
                    ids[i] = Integer.parseInt(idList.get(i));
                }
                tUsersService.DeleteTUsers(ids);
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().print(JSON.toJSONString(R.success()));
                break;
            case "update":
                TUsers updateTUsers = getTUsers(request);
                tUsersService.UpdateTUser(updateTUsers);
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().print(JSON.toJSONString(R.success()));
                break;
            case "upPwd":
                TUsers upPwdTUser = (TUsers) request.getSession().getAttribute("tUser");
                String oldPassword = request.getParameter("oldPassword");
                String newPassword = request.getParameter("newPassword");
                if (upPwdTUser.getPassword().equals(oldPassword)) {
                    upPwdTUser.setPassword(newPassword);
                    tUsersService.UpdateTUser(upPwdTUser);
                    request.setAttribute("returnMsg", "修改成功！");
                    request.getRequestDispatcher("updatePassword.jsp").forward(request, response);
                } else {
                    request.setAttribute("returnMsg", "旧密码不正确！");
                    request.getRequestDispatcher("updatePassword.jsp").forward(request, response);
                }
                break;
            case "offline":
                Integer id = Integer.valueOf(request.getParameter("id"));
                List<TUsers> offlineTUsers = tUsersService.GetTUserById(id);
                TUsers tUser = offlineTUsers.get(0);
                System.out.println(tUser);
                Map<TUsers, Boolean> map = (Map<TUsers, Boolean>) request.getServletContext().getAttribute("online");
                System.out.println("old::" + map);
                System.out.println(map.containsKey(tUser));
                if (map.containsKey(id)) {   // 指定用户信息存在
                    map.put(tUser, false);   // 修改为注销状态
                    request.getServletContext().setAttribute("online", map);   // 属性更新
                    System.out.println("new::" + request.getServletContext().getAttribute("online"));
                }
                tUser.setStatus(0);
                tUsersService.UpdateTUser(tUser);
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().print(JSON.toJSONString(R.success()));
                break;
            case "upload":
                uploadFile(request, response);
                break;
            default:
                break;
        }
    }

    @SneakyThrows
    private TUsers getTUsers(HttpServletRequest request) {
        String id = request.getParameter("id") == null ? "" : request.getParameter("id");
        String userName = request.getParameter("userName");
        String account = request.getParameter("account");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String age = request.getParameter("age");
        String birthday = request.getParameter("birthday");
        String telephone = request.getParameter("telephone");
        String address = request.getParameter("address");
        String email = request.getParameter("email");
        String avatar = request.getParameter("avatar");
        String userType = request.getParameter("userType");
        String balance = request.getParameter("balance");
        TUsers tUsers = new TUsers();
        if (!id.isEmpty()) tUsers.setId(Integer.valueOf(id));
        if (userName != null && !userName.isEmpty()) tUsers.setUserName(userName);
        tUsers.setAccount(account);
        tUsers.setPassword(password);
        tUsers.setGender(Integer.valueOf(gender));
        if (age != null && !age.isEmpty()) tUsers.setAge(Integer.valueOf(age));
        if (birthday != null && !birthday.isEmpty()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            tUsers.setBirthday(simpleDateFormat.parse(birthday));
        }
        if (telephone != null && !telephone.isEmpty()) tUsers.setTelephone(telephone);
        if (address != null && !address.isEmpty()) tUsers.setAddress(address);
        if (email != null && !email.isEmpty()) tUsers.setEmail(email);
        if (avatar != null && !avatar.isEmpty()) tUsers.setAvatar(avatar);
        if (userType != null && !userType.isEmpty()) tUsers.setUserType(Integer.valueOf(userType));
        if (balance != null && !balance.isEmpty()) tUsers.setBalance(Double.valueOf(balance));
        return tUsers;
    }

    @SneakyThrows
    private void uploadFile(HttpServletRequest request, HttpServletResponse response) {
        //真实上传到的文件地址
        String filePath = "D:\\taojin\\avatars";
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        //解析请求信息
        List<FileItem> fileItems = upload.parseRequest(request);
        String fileName = "";
        Iterator<FileItem> iterator = fileItems.iterator();
        if (iterator.hasNext()) {
            FileItem item = iterator.next();
            fileName = item.getName();
            //获取文件的后缀名
            String suffName = fileName.substring(fileName.lastIndexOf("."));
            //随机生成文件名称
            fileName = UUID.randomUUID() + suffName;
            request.setAttribute("fileName", fileName);
            File f = new File(filePath);
            if (!f.exists()) {
                f.mkdirs();
            }
            File file = new File(filePath, fileName);
            item.write(file);
        }
        response.setContentType("application/json;charset=utf-8");
        String json = JSON.toJSONString(R.success(fileName, null));
        response.getWriter().print(json);
    }

}
