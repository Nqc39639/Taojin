package com.taojin.mapper;

import com.taojin.pojo.TGoodsTypes;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TGoodsTypesMapper {
    List<TGoodsTypes> selectAll();

    List<TGoodsTypes> selectById(@Param("id") int id);

    List<TGoodsTypes> selectByGoodsTypesName(@Param("goodsTypesName") String goodsTypesName);

    int[] selectTGoodsIdByTypeId(int goodsTypeId);
}
