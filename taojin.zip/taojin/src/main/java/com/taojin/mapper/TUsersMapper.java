package com.taojin.mapper;

import com.taojin.pojo.TUsers;
import com.taojin.pojo.TUsersSearch;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TUsersMapper {
    List<TUsers> selectAll();

    List<TUsers> selectOnline();

    List<TUsers> selectById(@Param("id") Integer id);

    TUsers selectByUserName(@Param("userName") String UserName);

    List<TUsers> selectByAccount(@Param("account") String account);

    List<TUsers> check(@Param("account") String account, @Param("password") String password);

    List<TUsers> selectBySearchAll(TUsersSearch search);

    List<TUsers> selectBySearchOnline(TUsersSearch search);

    Integer add(TUsers tUsers);

    void delete(@Param("ids") int[] ids);

    void update(TUsers tUsers);
}
