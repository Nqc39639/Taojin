package com.taojin.mapper;

import com.taojin.pojo.TGoods;
import com.taojin.pojo.TGoodsSearch;
import com.taojin.pojo.TGoodsSearchParams;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TGoodsMapper {
    List<TGoods> selectAll();

    List<TGoods> selectAllInRequest();

    List<TGoods> selectAllInSell();

    List<TGoods> selectById(@Param("id") Integer id);

    List<TGoods> selectByIds(@Param("ids") int[] ids);

    List<TGoods> selectByConditions(TGoodsSearchParams searchPara);

    List<TGoods> selectBySearchOnSaleStr(TGoodsSearch searchPara);

    List<TGoods> selectBySearchForBuyingStr(TGoodsSearch searchPara);

    TGoods selectByTGoodsName(@Param("goodsName") String goodsName);

    List<TGoods> selectByTGoodsTypeId(@Param("goodsTypeId") Integer goodsTypeId);

    List<TGoods> selectByTGoodsStatus(@Param("goodsStatus") Integer goodsStatus);

    List<TGoods> selectByTGoodsPriceIn(@Param("min") Double min, @Param("max") Double max);

    List<TGoods> selectByTGoodsPriceMoreThan(@Param("min") Double min);

    Integer add(TGoods tGoods);

    Integer delete(@Param("ids") int[] ids);

    Integer update(TGoods tGoods);

}
