package com.taojin.mapper;

import com.taojin.pojo.TGoodsReviews;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TGoodsReviewsMapper {
    List<TGoodsReviews> selectAll();

    List<TGoodsReviews> selectByTGoodsId(@Param("goodsId") Integer goodsId);

    List<TGoodsReviews> selectBySearchReviews(@Param("userId") Integer userId, @Param("goodsId") Integer goodsId, @Param("time_min") String time_min, @Param("time_max") String time_max);

    Integer add(TGoodsReviews tGoodsReviews);
}
