package com.taojin.util;

import com.taojin.pojo.TUsers;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.util.HashMap;
import java.util.Map;

@WebListener
public class OnlineListener implements   // 在线用户监听类
        ServletContextListener,   // ServletContext状态监听
        HttpSessionListener,   // Session状态监听
        HttpSessionAttributeListener {   // Session属性监听

    public ServletContext application;   // Servlet上下文

    public ServletContext getApplication() {
        return application;
    }

    public void setApplication(ServletContext application) {
        this.application = application;
    }

    @Override
    public void contextInitialized(ServletContextEvent event) {   // 上下文初始化
        this.application = event.getServletContext();   // 获取Servlet上下文对象
        this.application.setAttribute("online", new HashMap<Integer, Boolean>());   // 空列表
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {   // 属性增加
        if ("tUser".equals(event.getName())) {   // 当前操作属性为userid
            Map<Integer, Boolean> map = (Map<Integer, Boolean>) this.application.getAttribute("online");   // 获取用户列表集合
            // Map集合的key表示登录用户名，Map集合的Value表示剔除状态（true表示该用户被剔除）
            map.put((Integer) event.getValue(), ((TUsers) event.getValue()).getStatus() == 1);   // 保存用户信息
            this.application.setAttribute("online", map);   // 属性更新
        }
    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent httpSessionBindingEvent) {

    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent httpSessionBindingEvent) {

    }

    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {

    }

    @Override
    public void sessionDestroyed(HttpSessionEvent event) {   // 注销删除用户名
        Map<TUsers, Boolean> map = (Map<TUsers, Boolean>) this.application.getAttribute("online");   // 获取用户列表集合
        map.remove(event.getSession().getAttribute("tUser"));   // 删除信息
        this.application.setAttribute("online", map);   // 属性更新
    }
}

