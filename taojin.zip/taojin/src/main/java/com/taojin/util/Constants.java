package com.taojin.util;

public class Constants {
    public final static int SUCCESS_CODE = 0;
    public final static int FAIL_CODE = 400;
    public final static String SUCCESS_MSG = "请求成功";
    public final static String FAIL_MSG = "请求失败";
}
