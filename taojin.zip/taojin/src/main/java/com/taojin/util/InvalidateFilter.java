package com.taojin.util;

import com.taojin.pojo.TUsers;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

// @WebFilter(
//         urlPatterns = {"/*"},
//         dispatcherTypes = {DispatcherType.REQUEST, DispatcherType.FORWARD}
// )
public class InvalidateFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        String uri = req.getServletContext().getContextPath() + ((HttpServletRequest) req).getRequestURI();
        if ((!uri.equals("/loginRegister.jsp") && uri.endsWith(".jsp") && !uri.equals("/home.jsp") && !uri.equals("/goodsDetails.jsp"))) {
            HttpServletRequest request = (HttpServletRequest) req;
            HttpServletResponse response = (HttpServletResponse) res;
            TUsers tUser = (TUsers) request.getSession().getAttribute("tUser");   // 获取用户ID
            if (tUser != null) {   // 用户已登录
                Map<TUsers, Boolean> map = (Map<TUsers, Boolean>) request.getServletContext().getAttribute("online");   // 获取用户集合
                if (map != null && map.containsKey(tUser)) {   // 指定用户信息存在
                    if (!map.get(tUser)) {   // 用户不在线
                        request.getSession().invalidate();   // Session强制清除
                        request.setAttribute("error", "您的账户已被系统强制下线，为了您的安全，请重新登录！");
                        request.getRequestDispatcher("/home.jsp").forward(request, response);   // 跳转
                    } else {   // 转发目标路径
                        chain.doFilter(request, response);   // 转发请求目标
                    }
                }
            } else {   // 用户未登录
                request.setAttribute("error", "您还未登录，请先登录！");   // 错误信息
                request.getRequestDispatcher("/home.jsp").forward(request, response);   // 跳转
            }
        } else {
            chain.doFilter(req, res);
        }
    }

    @Override
    public void destroy() {

    }

    // private boolean isServletRequest(String uri) {
    //     // 在这里添加你判断是否是 servlet 请求的逻辑
    //     // 可以根据自己的项目结构和规范来实现，例如检查是否有对应的 servlet 映射
    //     // 这里只是一个示例，实际情况需要根据具体项目进行调整
    //     return uri.startsWith("/servlet/");
    // }

}
