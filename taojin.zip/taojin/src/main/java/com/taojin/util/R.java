package com.taojin.util;

public class R {
    private static final long serialVersionUID = 1L;
    private final Integer code;
    private final String msg;
    private final Object data;
    private long count;

    public R(int code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    private R(int code, String msg, long count, Object data) {
        this.code = code;
        this.msg = msg;
        this.count = count;
        this.data = data;
    }

    public static R success() {
        return new R(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, null);
    }

    public static R success(Object data) {
        return new R(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, data);
    }

    public static R success(String msg, Object data) {
        return new R(Constants.SUCCESS_CODE, msg, data);
    }

    public static R success(long count, Object data) {
        return new R(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, count, data);
    }

    public static R success(String msg, long count, Object data) {
        return new R(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, count, data);
    }

    public static R fail() {
        return new R(Constants.FAIL_CODE, Constants.FAIL_MSG, null);
    }

    public static R fail(String msg) {
        return new R(Constants.FAIL_CODE, msg, null);
    }

    public static R fail(int errorCode, String msg) {
        return new R(errorCode, msg, null);
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public Object getData() {
        return data;
    }

    public Long getCount() {
        return count;
    }

    public R setCount(Long count) {
        this.count = count;
        return this;
    }
}
